# Max TV — projeto Android v1.2

Aplicativo Android nativo em Kotlin com interface escura, navegação inferior, biblioteca por categorias, player Media3/ExoPlayer, importação M3U por HTTPS e conexão Xtream Codes por HTTPS.

## Novidades da versão 1.2
- Conexão Xtream Codes usando servidor, usuário e senha.
- Carregamento de categorias de TV ao vivo, filmes e séries, conforme o catálogo informado pelo servidor.
- Favoritos salvos localmente no aparelho.
- Consulta de programação EPG resumida para canais ao vivo Xtream que disponibilizem essa informação.
- Player com tela cheia.

## Requisitos
- Android Studio atualizado
- JDK 17
- Android SDK 35
- Internet para baixar dependências Gradle

## Abrir e gerar APK
1. Extraia o ZIP.
2. No Android Studio, selecione **Open** e escolha a pasta `MaxTV-Android`.
3. Aguarde a sincronização do Gradle.
4. Para gerar: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de depuração normalmente ficará em `app/build/outputs/apk/debug/app-debug.apk`.

## O que funciona
- Abas Início, Ao vivo, Filmes, Séries, Favoritos e Ajustes.
- Importação de lista M3U por URL HTTPS.
- Login Xtream Codes por HTTPS.
- Listagem de canais ao vivo, filmes e catálogo de séries; reprodução direta de canais e filmes.
- Favoritos persistidos no aparelho.
- Consulta EPG resumida para canais ao vivo Xtream, quando o servidor oferece dados EPG.
- Reprodução de streams compatíveis com Media3/ExoPlayer.

## Limitações importantes
- A reprodução de episódios de séries ainda não está implementada; a versão lista os títulos do catálogo.
- EPG depende da disponibilidade e do formato de dados fornecidos pelo servidor Xtream.
- Nem todo servidor ou stream é compatível; os provedores podem variar endpoints, formatos e permissões.
- Credenciais Xtream são guardadas nas preferências privadas do app neste protótipo; ainda não há cofre criptográfico dedicado.
- O projeto foi atualizado, mas não foi compilado/testado neste ambiente. A compilação deve ser verificada no Android Studio.
- Este pacote contém código-fonte, não um APK compilado. O app não fornece canais, filmes, séries ou assinaturas. Use somente listas e serviços que você tenha autorização para acessar.
