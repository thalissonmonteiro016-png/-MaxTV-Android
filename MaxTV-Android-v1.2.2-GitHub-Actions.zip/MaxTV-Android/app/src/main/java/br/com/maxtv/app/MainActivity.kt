package br.com.maxtv.app

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors

private const val BG = 0xFF080E1B.toInt()
private const val PANEL = 0xFF111C2E.toInt()
private const val PANEL_2 = 0xFF1A2940.toInt()
private const val WHITE = 0xFFF5F7FB.toInt()
private const val MUTED = 0xFF9BAAC0.toInt()
private const val ACCENT = 0xFF26C6A3.toInt()

data class Channel(
    val name: String,
    val streamUrl: String,
    val group: String = "Outros",
    val kind: String = "live"
)

class MainActivity : Activity() {
    private val worker = Executors.newSingleThreadExecutor()
    private var player: ExoPlayer? = null
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var playerView: PlayerView
    private lateinit var urlInput: EditText
    private lateinit var status: TextView
    private lateinit var navBar: LinearLayout
    private var allItems: List<Channel> = emptyList()
    private var activeTab = "Início"
    private var selectedGroup = "Todos"
    private var currentItem: Channel? = null
    private var fullScreen = false
    private lateinit var serverInput: EditText
    private lateinit var userInput: EditText
    private lateinit var passInput: EditText
    private val favorites = mutableSetOf<String>()
    private val prefs by lazy { getSharedPreferences("maxtv", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = Color.BLACK
        player = ExoPlayer.Builder(this).build()
        favorites.addAll(prefs.getStringSet("favorites", emptySet()) ?: emptySet())
        buildShell()
        showHome()
    }

    private fun buildShell() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(14), dp(20), dp(12))
            setBackgroundColor(BG)
        }
        val brand = TextView(this).apply {
            text = "MAX"
            textSize = 25f
            setTextColor(WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        }
        val tv = TextView(this).apply {
            text = " TV"
            textSize = 25f
            setTextColor(ACCENT)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        }
        val brandWrap = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(brand)
            addView(tv)
        }
        header.addView(brandWrap, LinearLayout.LayoutParams(0, -2, 1f))
        val connect = TextView(this).apply {
            text = "●  LISTA"
            textSize = 11f
            setTextColor(ACCENT)
            setPadding(dp(10), dp(7), dp(10), dp(7))
            background = rounded(PANEL_2, 30)
            setOnClickListener { showSettings() }
        }
        header.addView(connect)
        root.addView(header)

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))

        navBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(7), dp(4), dp(7))
            setBackgroundColor(0xFF0D1727.toInt())
        }
        listOf("Início", "Ao vivo", "Filmes", "Séries", "Favoritos", "Ajustes").forEach { tab ->
            val item = TextView(this).apply {
                text = when (tab) {
                    "Início" -> "⌂\nInício"
                    "Ao vivo" -> "◉\nAo vivo"
                    "Filmes" -> "▣\nFilmes"
                    "Séries" -> "▤\nSéries"
                    "Favoritos" -> "★\nFavoritos"
                    else -> "⚙\nAjustes"
                }
                gravity = Gravity.CENTER
                textSize = 10f
                setTextColor(if (tab == activeTab) ACCENT else MUTED)
                setPadding(dp(4), dp(5), dp(4), dp(5))
                setOnClickListener { selectTab(tab) }
            }
            navBar.addView(item, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(navBar)
        setContentView(root)
    }

    private fun selectTab(tab: String) {
        if (tab != activeTab) selectedGroup = "Todos"
        activeTab = tab
        when (tab) {
            "Início" -> showHome()
            "Ao vivo" -> showLibrary("live")
            "Filmes" -> showLibrary("movie")
            "Séries" -> showLibrary("series")
            "Favoritos" -> showFavorites()
            "Ajustes" -> showSettings()
        }
        refreshNav()
    }

    private fun refreshNav() {
        navBar.removeAllViews()
        listOf("Início", "Ao vivo", "Filmes", "Séries", "Favoritos", "Ajustes").forEach { tab ->
            val item = TextView(this).apply {
                text = when (tab) {
                    "Início" -> "⌂\nInício"
                    "Ao vivo" -> "◉\nAo vivo"
                    "Filmes" -> "▣\nFilmes"
                    "Séries" -> "▤\nSéries"
                    "Favoritos" -> "★\nFavoritos"
                    else -> "⚙\nAjustes"
                }
                gravity = Gravity.CENTER
                textSize = 10f
                setTextColor(if (tab == activeTab) ACCENT else MUTED)
                setPadding(dp(4), dp(5), dp(4), dp(5))
                setOnClickListener { selectTab(tab) }
            }
            navBar.addView(item, LinearLayout.LayoutParams(0, -2, 1f))
        }
    }

    private fun resetContent() {
        content.removeAllViews()
        fullScreen = false
        navBar.visibility = View.VISIBLE
    }

    private fun showHome() {
        resetContent()
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(8), dp(18), dp(22))
        }
        scroll.addView(page)

        val greeting = label("Bem-vindo ao", 14f, MUTED)
        page.addView(greeting)
        val heading = label("seu entretenimento.", 25f, WHITE, true)
        page.addView(heading)

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF173D4B.toInt(), 0xFF17233B.toInt(), 0xFF241D3D.toInt())
            ).apply { cornerRadius = dp(20).toFloat() }
        }
        val liveTag = label("MAX TV  •  CENTRAL DE CONTEÚDO", 10f, ACCENT, true)
        hero.addView(liveTag)
        val heroTitle = label("Tudo em um só lugar", 22f, WHITE, true)
        heroTitle.setPadding(0, dp(10), 0, dp(4))
        hero.addView(heroTitle)
        hero.addView(label("Adicione sua lista e assista aos conteúdos disponíveis nela.", 13f, 0xFFD0D9E6.toInt()))
        val heroButton = actionButton("ADICIONAR MINHA LISTA") { showSettings() }
        heroButton.setTextColor(Color.BLACK)
        heroButton.background = rounded(ACCENT, 12)
        val buttonParams = LinearLayout.LayoutParams(-1, dp(46))
        buttonParams.topMargin = dp(16)
        hero.addView(heroButton, buttonParams)
        val heroParams = LinearLayout.LayoutParams(-1, -2)
        heroParams.topMargin = dp(18)
        page.addView(hero, heroParams)

        page.addView(sectionTitle("Explorar"))
        val shortcuts = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("◉  Ao vivo", "▣  Filmes", "▤  Séries").forEachIndexed { index, text ->
            val b = actionButton(text) {
                selectTab(listOf("Ao vivo", "Filmes", "Séries")[index])
            }
            b.textSize = 12f
            b.background = rounded(PANEL_2, 14)
            b.setTextColor(WHITE)
            val lp = LinearLayout.LayoutParams(0, dp(52), 1f)
            lp.marginEnd = dp(7)
            shortcuts.addView(b, lp)
        }
        val shortcutParams = LinearLayout.LayoutParams(-1, -2)
        shortcutParams.topMargin = dp(10)
        page.addView(shortcuts, shortcutParams)

        page.addView(sectionTitle("Reprodução"))
        playerView = PlayerView(this).apply {
            useController = true
            player = this@MainActivity.player
            setBackgroundColor(Color.BLACK)
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
        }
        page.addView(playerView, LinearLayout.LayoutParams(-1, dp(190)))
        val full = actionButton("ABRIR PLAYER EM TELA CHEIA") { toggleFullScreen() }
        full.background = rounded(PANEL_2, 12)
        full.setTextColor(WHITE)
        val fullParams = LinearLayout.LayoutParams(-1, dp(42))
        fullParams.topMargin = dp(7)
        page.addView(full, fullParams)

        page.addView(sectionTitle("Sua lista"))
        status = label(
            if (allItems.isEmpty()) "Nenhuma lista carregada. Entre em Ajustes para adicionar uma lista M3U."
            else "${allItems.size} itens carregados na sua biblioteca.",
            13f, MUTED
        )
        page.addView(status)
        val browse = actionButton("VER CONTEÚDOS DISPONÍVEIS") {
            selectTab("Ao vivo")
        }
        browse.background = rounded(PANEL, 12)
        browse.setTextColor(WHITE)
        val browseParams = LinearLayout.LayoutParams(-1, dp(44))
        browseParams.topMargin = dp(10)
        page.addView(browse, browseParams)

        content.addView(scroll, LinearLayout.LayoutParams(-1, -1))
    }

    private fun showSettings() {
        resetContent()
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(24))
        }
        page.addView(label("Configurações", 25f, WHITE, true))
        page.addView(label("Conecte uma lista IPTV que você tenha autorização para usar.", 13f, MUTED).apply {
            setPadding(0, dp(5), 0, dp(18))
        })
        page.addView(sectionTitle("Lista M3U por endereço"))
        urlInput = EditText(this).apply {
            hint = "https://servidor.com/sua-lista.m3u"
            textSize = 14f
            singleLine = true
            setTextColor(WHITE)
            setHintTextColor(MUTED)
            setPadding(dp(14), 0, dp(14), 0)
            background = rounded(PANEL_2, 12)
        }
        page.addView(urlInput, LinearLayout.LayoutParams(-1, dp(52)))
        val load = actionButton("CONECTAR LISTA") { loadPlaylist() }
        load.background = rounded(ACCENT, 12)
        load.setTextColor(Color.BLACK)
        val loadParams = LinearLayout.LayoutParams(-1, dp(48))
        loadParams.topMargin = dp(10)
        page.addView(load, loadParams)

        page.addView(sectionTitle("Acesso Xtream Codes"))
        page.addView(label("Informe os dados fornecidos pelo seu serviço autorizado.", 12f, MUTED).apply {
            setPadding(0, 0, 0, dp(8))
        })
        serverInput = settingsField("https://servidor.com:porta", false)
        userInput = settingsField("Usuário", false)
        passInput = settingsField("Senha", true)
        page.addView(serverInput, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(8) })
        page.addView(userInput, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(8) })
        page.addView(passInput, LinearLayout.LayoutParams(-1, dp(50)))
        serverInput.setText(prefs.getString("xt_server", ""))
        userInput.setText(prefs.getString("xt_user", ""))
        passInput.setText(prefs.getString("xt_pass", ""))
        val xtream = actionButton("CONECTAR COM XTREAM") { connectXtream() }
        xtream.background = rounded(PANEL_2, 12)
        xtream.setTextColor(WHITE)
        page.addView(xtream, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(9) })

        status = label(
            if (allItems.isEmpty()) "Aguardando uma lista M3U ou acesso Xtream."
            else "Lista carregada: ${allItems.size} itens.",
            13f, MUTED
        )
        status.setPadding(0, dp(12), 0, dp(12))
        page.addView(status)
        page.addView(sectionTitle("Sobre o Max TV"))
        page.addView(label("Versão 1.2 • Player Android com Media3", 13f, MUTED))
        page.addView(label("O Max TV não fornece canais, filmes ou assinaturas. Você precisa adicionar uma lista própria ou licenciada.", 12f, MUTED).apply {
            setPadding(0, dp(8), 0, 0)
        })
        scroll.addView(page)
        content.addView(scroll, LinearLayout.LayoutParams(-1, -1))
    }

    private fun showLibrary(kind: String) {
        resetContent()
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(24))
        }
        val title = when (kind) {
            "live" -> "TV ao vivo"
            "movie" -> "Filmes"
            else -> "Séries"
        }
        page.addView(label(title, 25f, WHITE, true))
        page.addView(label("Conteúdos encontrados na sua lista", 13f, MUTED).apply {
            setPadding(0, dp(4), 0, dp(14))
        })

        val filtered = allItems.filter { it.kind == kind }
        val groups = listOf("Todos") + filtered.map { it.group }.distinct().sorted()
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        groups.forEach { group ->
            val chip = TextView(this).apply {
                text = group
                textSize = 12f
                setTextColor(if (selectedGroup == group) Color.BLACK else WHITE)
                setPadding(dp(13), dp(9), dp(13), dp(9))
                background = rounded(if (selectedGroup == group) ACCENT else PANEL_2, 30)
                setOnClickListener {
                    selectedGroup = group
                    showLibrary(kind)
                }
            }
            val lp = LinearLayout.LayoutParams(-2, -2)
            lp.marginEnd = dp(7)
            chips.addView(chip, lp)
        }
        val chipScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(chips)
        }
        page.addView(chipScroll)

        val visible = if (selectedGroup == "Todos") filtered else filtered.filter { it.group == selectedGroup }
        if (visible.isEmpty()) {
            val empty = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(20), dp(42), dp(20), dp(42))
                addView(label("▣", 34f, ACCENT, true).apply { gravity = Gravity.CENTER })
                addView(label("Sua biblioteca está vazia", 17f, WHITE, true).apply {
                    gravity = Gravity.CENTER
                    setPadding(0, dp(8), 0, dp(5))
                })
                addView(label("Adicione uma lista M3U em Ajustes para carregar seus conteúdos.", 13f, MUTED).apply {
                    gravity = Gravity.CENTER
                })
                val b = actionButton("IR PARA AJUSTES") { selectTab("Ajustes") }
                b.background = rounded(ACCENT, 12)
                b.setTextColor(Color.BLACK)
                addView(b, LinearLayout.LayoutParams(-1, dp(45)).apply { topMargin = dp(18) })
            }
            page.addView(empty, LinearLayout.LayoutParams(-1, -2))
        } else {
            page.addView(label("${visible.size} conteúdos", 12f, MUTED).apply {
                setPadding(0, dp(14), 0, dp(8))
            })
            visible.take(500).forEach { item ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(12), dp(10), dp(12), dp(10))
                    background = rounded(PANEL, 12)
                    setOnClickListener { play(item) }
                }
                val icon = TextView(this).apply {
                    text = if (kind == "live") "▶" else "▣"
                    textSize = 18f
                    setTextColor(ACCENT)
                    gravity = Gravity.CENTER
                    background = rounded(PANEL_2, 10)
                }
                row.addView(icon, LinearLayout.LayoutParams(dp(42), dp(42)))
                val info = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(10), 0, dp(8), 0)
                    addView(label(item.name, 14f, WHITE, true))
                    addView(label(item.group, 11f, MUTED))
                }
                row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
                val star = TextView(this).apply {
                    text = if (favorites.contains(favoriteKey(item))) "★" else "☆"
                    textSize = 22f
                    setTextColor(ACCENT)
                    setPadding(dp(8), dp(4), dp(8), dp(4))
                    setOnClickListener { toggleFavorite(item) ; showLibrary(kind) }
                }
                row.addView(star)
                row.addView(label("▶", 15f, ACCENT, true))
                val lp = LinearLayout.LayoutParams(-1, -2)
                lp.bottomMargin = dp(8)
                page.addView(row, lp)
            }
        }
        scroll.addView(page)
        content.addView(scroll, LinearLayout.LayoutParams(-1, -1))
    }

    private fun settingsField(hintText: String, password: Boolean): EditText = EditText(this).apply {
        hint = hintText
        textSize = 14f
        singleLine = true
        setTextColor(WHITE)
        setHintTextColor(MUTED)
        setPadding(dp(14), 0, dp(14), 0)
        background = rounded(PANEL_2, 12)
        if (password) inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
    }

    private fun connectXtream() {
        val server = serverInput.text.toString().trim().trimEnd('/')
        val username = userInput.text.toString().trim()
        val password = passInput.text.toString().trim()
        if (!server.startsWith("https://") || username.isBlank() || password.isBlank()) {
            Toast.makeText(this, "Preencha servidor HTTPS, usuário e senha.", Toast.LENGTH_LONG).show()
            return
        }
        prefs.edit().putString("xt_server", server).putString("xt_user", username).putString("xt_pass", password).apply()
        status.text = "Conectando ao serviço..."
        worker.execute {
            try {
                val encodedUser = URLEncoder.encode(username, "UTF-8")
                val encodedPass = URLEncoder.encode(password, "UTF-8")
                val api = "$server/player_api.php?username=$encodedUser&password=$encodedPass"
                val auth = JSONObject(httpGet(api))
                if (auth.optJSONObject("user_info")?.optString("auth") == "0") throw Exception("Acesso recusado")
                val loaded = mutableListOf<Channel>()
                val actions = listOf("get_live_streams", "get_vod_streams", "get_series")
                actions.forEach { action ->
                    val arr = JSONArray(httpGet("$api&action=$action"))
                    for (i in 0 until arr.length()) {
                        val obj = arr.optJSONObject(i) ?: continue
                        val name = obj.optString("name", "Conteúdo")
                        val categoryId = obj.optString("category_id", "")
                        val group = categoryName(api, action, categoryId)
                        val id = obj.optString("stream_id", obj.optString("series_id", ""))
                        val kind = when (action) { "get_live_streams" -> "live"; "get_vod_streams" -> "movie"; else -> "series" }
                        val ext = obj.optString("container_extension", "mp4").ifBlank { "mp4" }
                        val stream = when (kind) {
                            "live" -> "$server/live/$encodedUser/$encodedPass/$id.ts"
                            "movie" -> "$server/movie/$encodedUser/$encodedPass/$id.$ext"
                            else -> ""
                        }
                        if (id.isNotBlank()) loaded.add(Channel(name, stream, group, kind))
                    }
                }
                runOnUiThread {
                    allItems = loaded
                    selectedGroup = "Todos"
                    status.text = "Xtream conectado: ${loaded.size} itens carregados."
                    Toast.makeText(this, status.text, Toast.LENGTH_LONG).show()
                    selectTab("Início")
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Não foi possível conectar. Confira os dados e se o serviço está disponível."
                    Toast.makeText(this, "Falha no acesso Xtream.", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private val categoryCache = mutableMapOf<String, Map<String, String>>()
    private fun categoryName(api: String, action: String, id: String): String {
        if (id.isBlank()) return "Outros"
        val categoryAction = when (action) {
            "get_live_streams" -> "get_live_categories"
            "get_vod_streams" -> "get_vod_categories"
            else -> "get_series_categories"
        }
        val key = categoryAction
        val names = categoryCache[key] ?: try {
            val arr = JSONArray(httpGet("$api&action=$categoryAction"))
            buildMap {
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    put(obj.optString("category_id"), obj.optString("category_name", "Outros"))
                }
            }.also { categoryCache[key] = it }
        } catch (_: Exception) { emptyMap() }
        return names[id] ?: "Outros"
    }

    private fun httpGet(address: String): String {
        val connection = (URL(address).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 25000
            requestMethod = "GET"
            setRequestProperty("User-Agent", "MaxTV/1.2")
        }
        return try { connection.inputStream.bufferedReader().use { it.readText() } }
        finally { connection.disconnect() }
    }

    private fun favoriteKey(item: Channel): String = item.streamUrl

    private fun toggleFavorite(item: Channel) {
        val key = favoriteKey(item)
        val added = if (favorites.contains(key)) {
            favorites.remove(key)
            false
        } else {
            favorites.add(key)
            true
        }
        prefs.edit().putStringSet("favorites", favorites.toSet()).apply()
        Toast.makeText(
            this,
            if (added) "Adicionado aos favoritos" else "Removido dos favoritos",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun showFavorites() {
        resetContent()
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(14), dp(18), dp(20)) }
        page.addView(label("Meus favoritos", 25f, WHITE, true))
        page.addView(label("Seus conteúdos salvos neste aparelho", 13f, MUTED).apply { setPadding(0, dp(4), 0, dp(14)) })
        val saved = allItems.filter { favorites.contains(favoriteKey(it)) }
        if (saved.isEmpty()) page.addView(label("Você ainda não adicionou favoritos. Use ☆ ao lado de um conteúdo.", 14f, MUTED))
        saved.forEach { item ->
            val row = actionButton("★  ${item.name}  •  ${item.group}") { play(item) }
            row.gravity = Gravity.START or Gravity.CENTER_VERTICAL
            row.background = rounded(PANEL, 12)
            row.setTextColor(WHITE)
            page.addView(row, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(8) })
        }
        content.addView(page)
    }

    private fun fetchEpg(item: Channel) {
        val server = prefs.getString("xt_server", "") ?: ""
        val username = prefs.getString("xt_user", "") ?: ""
        val password = prefs.getString("xt_pass", "") ?: ""
        if (server.isBlank() || username.isBlank() || password.isBlank()) return
        val streamId = item.streamUrl.substringAfterLast('/').substringBefore('.')
        worker.execute {
            try {
                val url = "$server/player_api.php?username=${URLEncoder.encode(username, "UTF-8")}&password=${URLEncoder.encode(password, "UTF-8")}&action=get_short_epg&stream_id=$streamId& limit=3".replace("& limit", "&limit")
                val json = JSONObject(httpGet(url))
                val listings = json.optJSONArray("epg_listings") ?: JSONArray()
                val lines = (0 until listings.length()).mapNotNull { i ->
                    val entry = listings.optJSONObject(i) ?: return@mapNotNull null
                    val title = android.util.Base64.decode(entry.optString("title", ""), android.util.Base64.DEFAULT).toString(Charsets.UTF_8)
                    val desc = android.util.Base64.decode(entry.optString("description", ""), android.util.Base64.DEFAULT).toString(Charsets.UTF_8)
                    if (title.isBlank()) null else "• $title${if (desc.isBlank()) "" else "\n$desc"}"
                }
                if (lines.isNotEmpty()) runOnUiThread {
                    android.app.AlertDialog.Builder(this).setTitle("Programação • ${item.name}").setMessage(lines.joinToString("\n\n")).setPositiveButton("OK", null).show()
                }
            } catch (_: Exception) { }
        }
    }

    private fun loadPlaylist() {
        val address = urlInput.text.toString().trim()
        if (!address.startsWith("https://")) {
            Toast.makeText(this, "Use um endereço HTTPS válido.", Toast.LENGTH_LONG).show()
            return
        }
        status.text = "Conectando e lendo a lista..."
        worker.execute {
            try {
                val connection = (URL(address).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 15000
                    readTimeout = 25000
                    requestMethod = "GET"
                    setRequestProperty("User-Agent", "MaxTV/1.1")
                }
                val body = connection.inputStream.bufferedReader().use { it.readText() }
                connection.disconnect()
                val parsed = parseM3u(body)
                runOnUiThread {
                    allItems = parsed
                    selectedGroup = "Todos"
                    status.text = if (parsed.isEmpty()) "Nenhum item encontrado. Verifique se a lista é M3U válida."
                    else "Lista conectada! ${parsed.size} itens encontrados."
                    Toast.makeText(this, status.text, Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Falha ao conectar. Confira o endereço e sua internet."
                    Toast.makeText(this, "Não foi possível carregar a lista.", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun parseM3u(content: String): List<Channel> {
        val result = mutableListOf<Channel>()
        var name: String? = null
        var group = "Outros"
        content.lineSequence().forEach { raw ->
            val line = raw.trim()
            if (line.startsWith("#EXTINF", true)) {
                name = line.substringAfterLast(",").trim().ifBlank { "Conteúdo" }
                group = Regex("""group-title=["']([^"']+)["']""", RegexOption.IGNORE_CASE)
                    .find(line)?.groupValues?.getOrNull(1) ?: "Outros"
            } else if (line.startsWith("https://") && !line.startsWith("#")) {
                val combined = "$group $name".lowercase()
                val kind = when {
                    combined.contains("série") || combined.contains("series") || combined.contains("temporada") -> "series"
                    combined.contains("filme") || combined.contains("movie") || combined.contains("vod") -> "movie"
                    else -> "live"
                }
                result.add(Channel(name ?: "Canal ${result.size + 1}", line, group, kind))
                name = null
                group = "Outros"
            }
        }
        return result
    }

    private fun play(item: Channel) {
        if (item.streamUrl.isBlank()) {
            Toast.makeText(this, "Este item é uma série. A reprodução de episódios será adicionada na próxima etapa.", Toast.LENGTH_LONG).show()
            return
        }
        currentItem = item
        if (item.kind == "live") fetchEpg(item)
        player?.setMediaItem(MediaItem.fromUri(item.streamUrl))
        player?.prepare()
        player?.play()
        Toast.makeText(this, "Reproduzindo: ${item.name}", Toast.LENGTH_SHORT).show()
    }

    private fun toggleFullScreen() {
        if (!::playerView.isInitialized) return
        if (fullScreen) {
            fullScreen = false
            navBar.visibility = View.VISIBLE
            showHome()
        } else {
            fullScreen = true
            content.removeAllViews()
            navBar.visibility = View.GONE
            if (::playerView.isInitialized) playerView.player = null
            playerView = PlayerView(this).apply {
                useController = true
                player = this@MainActivity.player
                setBackgroundColor(Color.BLACK)
            }
            content.addView(playerView, LinearLayout.LayoutParams(-1, -1))
        }
    }

    private fun sectionTitle(text: String): TextView =
        label(text, 17f, WHITE, true).apply { setPadding(0, dp(22), 0, dp(8)) }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }

    private fun actionButton(text: String, action: () -> Unit) =
        Button(this).apply {
            this.text = text
            isAllCaps = false
            textSize = 13f
            setOnClickListener { action() }
        }

    private fun rounded(color: Int, radius: Int) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
        }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        if (::playerView.isInitialized) playerView.player = null
        player?.release()
        player = null
        worker.shutdown()
        super.onDestroy()
    }
}
