# Gerar o APK pelo celular usando GitHub Actions

1. Crie uma conta ou entre em https://github.com.
2. Crie um repositório novo (por exemplo, `MaxTV-Android`). Se aparecer a opção de público/privado, escolha privado se preferir manter o código restrito.
3. No repositório, use **Add file > Upload files** e envie o conteúdo da pasta `MaxTV-Android` extraída deste ZIP (não envie o ZIP como um único arquivo).
4. Faça o commit na branch `main`.
5. Abra a aba **Actions** do repositório. O fluxo **Build Max TV APK** deverá iniciar automaticamente após o envio. Se não iniciar, abra o fluxo e toque em **Run workflow**.
6. Quando terminar com sucesso, abra a execução e procure **Artifacts**. Baixe `MaxTV-debug-apk`.
7. Extraia o ZIP do artefato baixado. Dentro dele estará `app-debug.apk`; toque nele para instalar no Android e autorize a instalação desta fonte, se o sistema solicitar.

O APK de depuração serve para teste. Esta configuração não assina um APK de distribuição para publicação na Play Store.
